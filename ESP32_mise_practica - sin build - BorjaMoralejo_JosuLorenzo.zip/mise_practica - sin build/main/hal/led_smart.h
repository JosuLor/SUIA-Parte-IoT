#ifndef LED_SMART_H
#define LED_SMART_H

#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "led_strip.h"
#include "sdkconfig.h"

#define BLINK_GPIO CONFIG_BLINK_GPIO

void led_on_color(int R, int G, int B);
void led_off(void);

void blink_led(void);
void configure_led(void);

#endif // LED_SMART_H