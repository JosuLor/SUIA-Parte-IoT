#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"
#include "esp_log.h"

bool bt_write_enabled;
bool gpio_interrupt;

uint16_t selected_product_len;
unsigned char string_selected_product_id[2];
unsigned char* string_selected_product_qty;

void bt_ble_task(void *arg);