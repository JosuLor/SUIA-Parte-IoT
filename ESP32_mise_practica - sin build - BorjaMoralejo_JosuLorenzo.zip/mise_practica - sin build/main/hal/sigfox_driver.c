/* Sigfox Driver*/

#include "sigfox_driver.h"
#include "led_smart.h"
#include "bt_ble.h"
#include "light_sensor.h"
#include "time.h"
#include <stdio.h>

#define UART2_TXD       GPIO_NUM_18
#define UART2_RXD       GPIO_NUM_17

static const char* TAG_SIGFOX = "SIGFOX";

UARTData sigfox_read;
UARTData sigfox_write;

char uart_received[4];
int i_uart_read;

char localStringInt[5];

char stringToTransmit[8];

void sigfox_uart_init()
{

    uart_data_init(&sigfox_read);
    uart_data_init(&sigfox_write);

    uart_config_t uart_config = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    uart_driver_install(UART_NUM_2, 2*1024, 0, 0, NULL, 0);
    uart_param_config(UART_NUM_2, &uart_config);
    uart_set_pin(UART_NUM_2, UART2_TXD, UART2_RXD, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);

}

void sigfox_uart_task(void *arg)
{
    can_send_sigfox = true;

    while (1) {
        int fd;

        if ((fd = open("/dev/uart/2", O_RDWR)) == -1) {
            ESP_LOGE(TAG_SIGFOX, "Cannot open UART");
            vTaskDelay(5000 / portTICK_PERIOD_MS);
            continue;
        }

        // We have a driver now installed so set up the read/write functions to use driver also.
        esp_vfs_dev_uart_use_driver(2);

        while (1) {

            if (make_send_sigfox && can_send_sigfox) {

                if (string_selected_product_id == NULL) {

                } else {

                    sigfox_read.buffer[sigfox_read.buffer_index] = '\0';

                    string_selected_product_qty = malloc(sizeof("20\n"));
                    string_selected_product_qty[0] = '2';
                    string_selected_product_qty[1] = '0';
                    string_selected_product_qty[2] = '\0';

                    char aux_string_seconds[5];
                    sprintf(aux_string_seconds, "%d", t_light_off);

                    //printf("[str] product id: %s\n", string_selected_product_id);
                    printf("[str] product qty: %s\n", string_selected_product_qty);
                    printf("[int] presences: %d\n", presences_detected);
                    printf("[str] seconds interacting: %s\n", aux_string_seconds);

                    stringToTransmit[0] = string_selected_product_id[0];
                    stringToTransmit[1] = string_selected_product_id[1];

                    char aux_string3[5];
                    sprintf(aux_string3, "%d", presences_detected);
                    printf("presences detected: %d\n", presences_detected);
                    printf("aux_string3: %s\n", aux_string3);

                    if (presences_detected < 10) {
                        stringToTransmit[2] = '0';
                        stringToTransmit[3] = aux_string3[0];
                    } else {
                        stringToTransmit[2] = aux_string3[0];
                        stringToTransmit[3] = aux_string3[1];
                    }

                    if (t_light_off < 9) {
                        stringToTransmit[4] = '0';
                        stringToTransmit[5] = aux_string_seconds[0];
                    } else {
                        stringToTransmit[4] = aux_string_seconds[0];
                        stringToTransmit[5] = aux_string_seconds[1];
                    }

                    stringToTransmit[6] = string_selected_product_qty[0];
                    stringToTransmit[7] = string_selected_product_qty[1];

                    stringToTransmit[8] = '\0';
                    printf("stringToTransmit: %s\n", stringToTransmit);

                    write(fd, stringToTransmit, sizeof(stringToTransmit));
                    sigfox_read.new_line_flag = true;
                    sigfox_read.buffer_index = 0;
                    make_send_sigfox = false;

                    i_uart_read = 0;
                }

            }

            /*
            if (new_product_selection) {
                sigfox_read.buffer[sigfox_read.buffer_index] = '\0';

                for (int i = 0; i < 5; i++) localStringInt[i] = '\n';
                itoa(t_light_off, localStringInt, 10);
                for (int i = 0; i < 5; i++) if (localStringInt[i] == '\0') localStringInt[i] = '\n';

                stringToTransmit[0] = localString[0];
                for (int i = 0; i < 5; i++) stringToTransmit[i + 1] = localStringInt[i]; 
                stringToTransmit[6] = '\n';

                write(fd, stringToTransmit, sizeof(stringToTransmit));
                sigfox_read.new_line_flag = true;
                sigfox_read.buffer_index = 0;
                new_product_selection = false;

                uart_received[0] = ' '; uart_received[1] = ' '; uart_received[2] = ' '; uart_received[3] = ' ';
                i_uart_read = 0;
            }
            */

            int s;
            fd_set rfds;
            struct timeval tv = {
                .tv_sec = 5,
                .tv_usec = 0,
            };

            FD_ZERO(&rfds);
            FD_SET(fd, &rfds);

            s = select(fd + 1, &rfds, NULL, NULL, &tv);

            if (s < 0) {
                ESP_LOGE(TAG_SIGFOX, "Select failed: errno %d", errno);
                break;
            } else if (s == 0) {
                //ESP_LOGI(TAG_SIGFOX, "Timeout has been reached and nothing has been received");
            } else {
                if (FD_ISSET(fd, &rfds)) {
                    char buf;
                    if (read(fd, &buf, 1) > 0) {
                        
                        uart_received[i_uart_read] = buf;

                        i_uart_read++;

                        if(buf == '\n') {
                            sigfox_read.buffer[sigfox_read.buffer_index] = '\0';
                            sigfox_read.new_line_flag = true;
                            sigfox_read.buffer_index = 0;

                            if (uart_received[0] == 'O' && uart_received[1] == 'K') {
                                xTaskCreate(task_uart_received_led_ok, "task_uart_received_led_ok", 8192, NULL, 8, NULL);
                            }

                            if (uart_received[0] == 'N' && uart_received[1] == 'O' && uart_received[2] == 'T') {
                                xTaskCreate(task_uart_received_led_not, "task_uart_received_led_not", 8192, NULL, 8, NULL);
                            }

                            printf("UART Full Buffer Read: %c%c%c%c\n", 
                                uart_received[0], uart_received[1], uart_received[2], uart_received[3]);

                            can_send_sigfox = true;

                        } else {
                            if (sigfox_read.buffer_index < BUF_SIZE - 1) {
                                sigfox_read.buffer[sigfox_read.buffer_index++] = buf;
                            } else {
                                ESP_LOGW(TAG_SIGFOX, "Buffer lleno, descartando datos");
                                sigfox_read.buffer_index = 0;
                            }
                        }
                        ESP_LOGD(TAG_SIGFOX, "HEX[%d] - 0x%02X - %c", sigfox_read.buffer_index, buf, buf);

                    } else {
                        ESP_LOGE(TAG_SIGFOX, "UART read error");
                        break;
                    }
                } else {
                    ESP_LOGE(TAG_SIGFOX, "No FD has been set in select()");
                    break;
                }
            }
        }

        if(sigfox_write.new_line_flag){

            ESP_LOGE(TAG_SIGFOX, "ESP32 --> SIGFOX");
            sigfox_write.new_line_flag = false;

        }

        close(fd);
    }

    vTaskDelete(NULL);
}

void task_uart_received_led_ok(void *arg)
{
    uart_received_ok = true;

    led_on_color(0, 255, 0);

    vTaskDelay(3000 / portTICK_PERIOD_MS);

    led_off();

    uart_received_ok = false;

    vTaskDelete(NULL);
}

void task_uart_received_led_not(void *arg)
{
    uart_received_ok = true;

    led_on_color(255, 0, 0);

    vTaskDelay(3000 / portTICK_PERIOD_MS);

    led_off();

    uart_received_ok = false;

    vTaskDelete(NULL);
}