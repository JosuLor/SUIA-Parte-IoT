#include "sigfox_driver.h"
#include "light_sensor.h"
#include "led_smart.h"
#include "adc_read.h"
#include "bt_ble.h"
#include <stdlib.h>
#include "gpio_button.h"

static const char* TAG = "SENSORS";

void light_sensor_task(void *arg)
{

    uint32_t v_sensor = 0;
    uint32_t v_sensor_original = 0;

    uint32_t t_light_off_quarter = 0;
    bool currently_present = false;

    vTaskDelay(100 / portTICK_PERIOD_MS);

    v_sensor_original = adc_read_sensor(true);
    presences_detected = 0;

    while(1) {

        vTaskDelay(250 / portTICK_PERIOD_MS);

        if (!bt_write_enabled && !uart_received_ok) {

            v_sensor = adc_read_sensor(true);

            if (abs(v_sensor - v_sensor_original) > 250) {
                led_on_color(255, 165, 0);
                t_light_off_quarter++;

                if (t_light_off_quarter >= 4) {
                    t_light_off_quarter = 0;
                    t_light_off++;
                }

                if (!currently_present) {
                    presences_detected++;
                }

                currently_present = true;

            } else {
                led_off();

                currently_present = false;
            }

            ESP_LOGI(TAG, "[ LIGHT SENSOR ]: %d || SECONDS: %d || PRESENCES: %d", v_sensor, t_light_off, presences_detected);
        }

    }

    vTaskDelete(NULL);
}