#ifndef UART_DATA_H
#define UART_DATA_H

#include <stdbool.h>

#define BUF_SIZE 256

typedef struct {
    char buffer[BUF_SIZE];
    int buffer_index;
    bool new_line_flag;
} UARTData;

void uart_data_init(UARTData *data);
void uart_data_reset(UARTData *data);

#endif // UART_DATA_H