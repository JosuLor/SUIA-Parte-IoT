#ifndef UART_CONSOLE_H
#define UART_CONSOLE_H

#include "../headers.h"
#include "uart_data.h"
#include <stdint.h>
#include <stdbool.h>

extern UARTData cmd_read_console;

void console_uart_init();
void console_uart_task(void *arg);

#endif // UART_CONSOLE_H