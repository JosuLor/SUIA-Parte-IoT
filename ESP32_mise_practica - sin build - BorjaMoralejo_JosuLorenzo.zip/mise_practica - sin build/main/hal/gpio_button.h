#ifndef GPIO_BUTTON_H
#define GPIO_BUTTON_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"
#include "esp_log.h"

void gpio_button_init();
void gpio_button_task(void* arg);
void gpio_button_diff_task(void* arg);

bool bt_change;
int push_counter;

#endif // GPIO_BUTTON_H
