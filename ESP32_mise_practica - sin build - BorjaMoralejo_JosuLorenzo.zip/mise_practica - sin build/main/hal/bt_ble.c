#include "bt_ble.h"
#include "led_smart.h"

static const char* TAG = "[BT BLE]";

void bt_ble_task(void *arg)
{

    while(1) {

        if (gpio_interrupt) {
            gpio_interrupt = false;

            if (bt_write_enabled) {

                ESP_LOGI(TAG, "========================================");
                ESP_LOGI(TAG, "===== Escritura Bluetooth Activada =====");
                ESP_LOGI(TAG, "========================================");

                led_on_color(0, 0, 255);

                vTaskDelay(5000 / portTICK_PERIOD_MS);

                led_off();
                bt_write_enabled = false;

                ESP_LOGI(TAG, "========================================");
                ESP_LOGI(TAG, "=== Escritura Bluetooth Desactivada ====");
                ESP_LOGI(TAG, "========================================");

            } else {
                ESP_LOGI(TAG, "=======================================");
                ESP_LOGI(TAG, "=== Escritura Bluetooth Desactivada ===");
                ESP_LOGI(TAG, "=======================================");

                led_off();
                bt_write_enabled = false;
            }

        }

        vTaskDelay(500 / portTICK_PERIOD_MS);
    }

}