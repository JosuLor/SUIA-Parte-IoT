/* UART Console */

#include "uart_console.h"

static const char* TAG_CONSOLE = "CONSOLE";

UARTData cmd_read_console;

void console_uart_init()
{

    uart_data_init(&cmd_read_console);

    uart_config_t uart_config = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity    = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_APB,
    };
    uart_driver_install(UART_NUM_0, 2*1024, 0, 0, NULL, 0);
    uart_param_config(UART_NUM_0, &uart_config);
    uart_set_pin(UART_NUM_0, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
}

void console_uart_task(void *arg)
{

    while (1) {
        int fd;

        if ((fd = open("/dev/uart/0", O_RDWR)) == -1) {
            ESP_LOGE(TAG_CONSOLE, "Cannot open UART");
            vTaskDelay(5000 / portTICK_PERIOD_MS);
            continue;
        }

        // We have a driver now installed so set up the read/write functions to use driver also.
        esp_vfs_dev_uart_use_driver(0);

        while (1) {
            int s;
            fd_set rfds;
            struct timeval tv = {
                .tv_sec = 5,
                .tv_usec = 0,
            };

            FD_ZERO(&rfds);
            FD_SET(fd, &rfds);

            s = select(fd + 1, &rfds, NULL, NULL, &tv);

            if (s < 0) {
                ESP_LOGE(TAG_CONSOLE, "Select failed: errno %d", errno);
                break;
            } else if (s == 0) {
                //ESP_LOGI(TAG_CONSOLE, "Timeout has been reached and nothing has been received");
            } else {
                if (FD_ISSET(fd, &rfds)) {
                    char buf;
                    if (read(fd, &buf, 1) > 0) {
                        if(buf == '\n') {
                            cmd_read_console.buffer[cmd_read_console.buffer_index] = '\0';
                            ESP_LOGI(TAG_CONSOLE, "[%d]>: %s", cmd_read_console.buffer_index, cmd_read_console.buffer);
                            cmd_read_console.new_line_flag = true;
                            cmd_read_console.buffer_index = 0;
                        } else {
                            if (cmd_read_console.buffer_index < BUF_SIZE - 1) {
                                cmd_read_console.buffer[cmd_read_console.buffer_index++] = buf;
                            } else {
                                ESP_LOGW(TAG_CONSOLE, "Buffer lleno, descartando datos");
                                cmd_read_console.buffer_index = 0;
                            }
                        }
                        ESP_LOGD(TAG_CONSOLE, "Received: %c", buf);

                    } else {
                        ESP_LOGE(TAG_CONSOLE, "UART read error");
                        break;
                    }
                } else {
                    ESP_LOGE(TAG_CONSOLE, "No FD has been set in select()");
                    break;
                }
            }
        }

        close(fd);
    }

    vTaskDelete(NULL);
}