#ifndef SIGFOX_DRIVER_H
#define SIGFOX_DRIVER_H

#include "../headers.h"
#include "uart_data.h"
#include <stdint.h>
#include <stdbool.h>

extern UARTData sigfox_read;
extern UARTData sigfox_write;
bool uart_received_ok;
bool make_send_sigfox;
bool can_send_sigfox;

void sigfox_uart_init();
void sigfox_uart_task(void *arg);
void task_uart_received_led_ok(void *arg);
void task_uart_received_led_not(void *arg);

#endif // SIGFOX_DRIVER_H