#include "uart_data.h"
#include <string.h>
#include "esp_log.h"

void uart_data_init(UARTData *data) {
    memset(data->buffer, 0, BUF_SIZE);
    data->buffer_index = 0;
    data->new_line_flag = false;
}

void uart_data_reset(UARTData *data) {
    memset(data->buffer, 0, BUF_SIZE);
    data->buffer_index = 0;
    data->new_line_flag = false;
}
