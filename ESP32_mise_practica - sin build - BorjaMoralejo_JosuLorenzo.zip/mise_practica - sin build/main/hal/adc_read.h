#ifndef ADC_READ_H
#define ADC_READ_H

#include <stdio.h>
#include <stdlib.h>
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/adc.h"
#include "esp_adc_cal.h"

bool adc_calibration_init(void);
void adc_init();
uint32_t adc_read_sensor( bool cali_enable);
uint32_t adc_read_batt(esp_err_t ret, bool cali_enable);

#endif // ADC_READ_H