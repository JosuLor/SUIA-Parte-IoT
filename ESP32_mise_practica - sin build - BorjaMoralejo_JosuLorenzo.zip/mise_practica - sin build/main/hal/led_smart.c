/* Blink Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include "led_smart.h"

static const char *TAG = "LED";

// #define BLINK_GPIO GPIO_NUM_48
// #define CONFIG_BLINK_LED_RMT 1
// #define CONFIG_BLINK_LED_RMT_CHANNEL 

#define CONFIG_BLINK_LED_RMT 1
#define CONFIG_BLINK_LED_RMT_CHANNEL 0
#define CONFIG_BLINK_GPIO 48
#define CONFIG_BLINK_PERIOD 1000

static uint8_t s_led_state = 0;

static led_strip_t *pStrip_a;

void led_on_color(int R, int G, int B) {
    pStrip_a->set_pixel(pStrip_a, 0, R, G, B);
    pStrip_a->refresh(pStrip_a, 50);
}

void led_off(void) {
    pStrip_a->clear(pStrip_a, 50);
}

void blink_led(void)
{
    s_led_state = !s_led_state;
    
    /* If the addressable LED is enabled */
    if (s_led_state) {
        /* Set the LED pixel using RGB from 0 (0%) to 255 (100%) for each color */
        // pStrip_a->set_pixel(pStrip_a, 0, 16, 16, 16);
        pStrip_a->set_pixel(pStrip_a, 0, 2, 20, 2);
        
        /* Refresh the strip to send data */
        pStrip_a->refresh(pStrip_a, 100);
    } else {
        /* Set all LED off to clear all pixels */
        pStrip_a->clear(pStrip_a, 50);
    }
}

void configure_led(void)
{
    ESP_LOGI(TAG, "Initialization of smart-led");
    /* LED strip initialization with the GPIO and pixels number*/
    pStrip_a = led_strip_init(CONFIG_BLINK_LED_RMT_CHANNEL, BLINK_GPIO, 1);
    /* Set all LED off to clear all pixels */
    pStrip_a->clear(pStrip_a, 50);
}

// void app_main(void)
// {

//     /* Configure the peripheral according to the LED type */
//     configure_led();

//     while (1) {
//         ESP_LOGI(TAG, "Turning the LED %s!", s_led_state == true ? "ON" : "OFF");
//         blink_led();
//         /* Toggle the LED state */
//         s_led_state = !s_led_state;
//         vTaskDelay(CONFIG_BLINK_PERIOD / portTICK_PERIOD_MS);
//     }
// }
