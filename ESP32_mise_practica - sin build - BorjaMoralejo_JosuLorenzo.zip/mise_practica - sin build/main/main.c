/* UART Select Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/

#include "headers.h"
#include "hal/sigfox_driver.h"
#include "hal/uart_console.h"
#include "hal/adc_read.h"
#include "hal/led_smart.h"
#include "hal/gpio_button.h"
#include "hal/bt_ble.h"
#include "hal/light_sensor.h"
#include "gatts_demo.h"

static const char* TAG = "MAIN";

bool cali_enable;

void initialization(void)
{

    vTaskDelay(1000 / portTICK_PERIOD_MS);
    ESP_LOGI(TAG, "INIT");

    gpio_button_init();

    configure_led();
    
    cali_enable = adc_calibration_init();
    
    adc_init();

    vTaskDelay(500 / portTICK_PERIOD_MS);
    console_uart_init();
    vTaskDelay(100 / portTICK_PERIOD_MS);
    sigfox_uart_init();
    vTaskDelay(100 / portTICK_PERIOD_MS);
    
    xTaskCreate(console_uart_task, "console", 4*1024, NULL, 5, NULL);
    xTaskCreate(sigfox_uart_task, "sigfox", 4*1024, NULL, 2, NULL);

    //start gpio task
    xTaskCreate(gpio_button_task, "button", 2048, NULL, 10, NULL);

    //light sensor task
    xTaskCreate(light_sensor_task, "light", 8192, NULL, 8, NULL);

    bt_write_enabled = false;
    gpio_interrupt = false;

    //start task bluetooth ble
    xTaskCreate(bt_ble_task, "bt_ble", 8192, NULL, 12, NULL);

    //start task bluetooth ble
    xTaskCreate(gpio_button_diff_task, "button_diff", 8192, NULL, 12, NULL);

}

void app_main(void)
{
    esp_err_t ret = ESP_OK;
    uint32_t v_sensor = 0;
    uint32_t v_batt = 0;
    
    initialization();

    bt_init();

    /*
    while(1) {
        ESP_LOGE(TAG, "Nothing....");
        vTaskDelay(1000 / portTICK_PERIOD_MS);
        blink_led();
        if(cmd_read_console.new_line_flag){
            ESP_LOGE(TAG, "New console line ready: %s", cmd_read_console.buffer);
            cmd_read_console.new_line_flag = false;
        }

        if(sigfox_read.new_line_flag) {
            ESP_LOGE(TAG, "New Sigfox line ready: %s", sigfox_read.buffer);
            sigfox_read.new_line_flag = false;
        }


        ESP_LOGI(TAG, "Read ADC....");
        v_sensor = adc_read_sensor(cali_enable);
        vTaskDelay(pdMS_TO_TICKS(50));
        v_batt = adc_read_batt(ret, cali_enable);
        ESP_LOGI("ADC-VAL","RESULT: SENSOR: %d mV, BATT: %d mV ", v_sensor, v_batt );
    }
    */

    /*

    while(1) {
        ESP_LOGI(TAG, "[ MAIN LOOP ]");

        vTaskDelay(200 / portTICK_PERIOD_MS);
        
        //led_on_color(255, 0, 0);

        //led_off();

        if (!bt_change) {

            v_sensor = adc_read_sensor(cali_enable);

            vTaskDelay(250 / portTICK_PERIOD_MS);

            if (v_sensor > 3000) {
                led_on_color(255, 165, 0);
                t_250_ms++;

                if (t_250_ms >= 4) {
                    t_250_ms = 0;
                    t_sec++;
                }

            } else {
                led_off();
            }

        } else {
            led_on_color(0, 255, 0);
            vTaskDelay(5000 / portTICK_PERIOD_MS);
            bt_change = false;
            led_off();
        }

        


        // Enviar: durante cuanto tiempo se ha estado tocando el sensor
        // Enviar: lo del producto a cambiar con el Bluetooth del movil

    }

    */

}
