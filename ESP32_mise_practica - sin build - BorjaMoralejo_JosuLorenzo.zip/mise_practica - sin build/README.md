# Práctica MISE, código de ejemplo

Basado en: UART Select Example del SDK.