from flask import request
from flask import Response
from flask import render_template
from flask import redirect
from flask import url_for

from flask import Flask

import json

from datetime import datetime

app = Flask(__name__)

last_id="none_id"
last_payload_a= "none_payload"
last_payload_b= "none_payload"
last_payload_total = "none_payload"

@app.route('/')
def main_route():
    return redirect(url_for('hello_world'))

@app.route('/vista-empresa')
def hello_world():
    global last_id
    global last_payload_a
    global last_payload_b
    global last_payload_total

    with open("mysite/products.json", "r") as file:
        products = json.load(file)

    # Convertir 'last_restock' a datetime para ordenar
    for product in products:
        product['last_restock_datetime'] = datetime.strptime(product['last_restock'], '%Y-%m-%d-%H-%M')

    # Ordenar los productos por 'last_restock_datetime' en orden descendente
    productos_ordenados = sorted(products, key=lambda x: x['last_restock_datetime'], reverse=True)

    # Obtener los 10 últimos productos
    ultimos_productos = productos_ordenados[:10]

    # Generar el HTML para cada fila de la tabla
    table_rows_last = ""
    for product in ultimos_productos:
        last_restock_parts = product["last_restock"].split("-")
        last_restock_formatted = f"{last_restock_parts[0]}-{last_restock_parts[1]}-{last_restock_parts[2]} {last_restock_parts[3]}:{last_restock_parts[4]}"

        if product["in_warehouse"] < 100:
            warehouse_class = "bg-red-product"
        elif product["in_warehouse"] < 175:
            warehouse_class = "bg-orange-product"
        else:
            warehouse_class = ""

        # Crear la fila de la tabla con los campos necesarios
        table_rows_last += f"""
            <tr>
                <td class="td_izq" style="text-align: left;">{product['name']}</td>
                <td class="td_izq {warehouse_class}">{product['in_warehouse']}</td>
                <td class="td_izq">{last_restock_formatted}</td>
                <td class="td_izq"><img src="img/{product['photo']}.png" alt="{product['name']}" style="width: 50px; height: auto;"></td>
            </tr>
        """

    # Generar el HTML para cada fila de la tabla
    table_rows = ""
    for product in products:
        # Calcular horas y minutos a partir de avg_time_between_restocks
        total_minutes = product["avg_time_between_restocks"]
        hours = total_minutes // 60
        minutes = total_minutes % 60
        avg_time_between_restocks = f"{hours}h {minutes}m"

        last_restock_parts = product["last_restock"].split("-")
        last_restock_formatted = f"{last_restock_parts[0]}-{last_restock_parts[1]}-{last_restock_parts[2]} {last_restock_parts[3]}:{last_restock_parts[4]}"

        # Crear la fila de la tabla
        table_rows += f"""
            <tr>
                <td class="td_izq" style="text-align: left;">  {product['name']}</td>
                <td class="td_izq">{product['id']}</td>
                <td class="td_izq">{last_restock_formatted}</td>
                <td class="td_izq">{product['avg_consume_rate']}</td>
                <td class="td_izq">{product['last_interaction_time']}</td>
                <td class="td_izq">{avg_time_between_restocks}</td>
                <td class="td_izq">{product['in_warehouse']}</td>
                <td class="td_izq">
                    <a href="/vista-empresa-modificar?id={product["id"]}" style="text-decoration: none;">Modificar</a>
                </td>
            </tr>
        """

    with app.app_context():
        rendered = render_template('index.html', \
            title = "Todo a 100 Yuanes | Empresa", \
            id = last_id, \
            payload_a = last_payload_a, \
            payload_b = last_payload_b,
            payload_total = last_payload_total,
            n_last_products = 10,
            products = table_rows,
            last_products = table_rows_last)
    return rendered

@app.route('/vista-cliente')
def hello_world_cliente():

    with open("mysite/products.json", "r") as file:
        products = json.load(file)

    table_rows = ""
    row_open = False

    for index, product in enumerate(products):
        # Abrir una nueva fila cada 4 productos
        if index % 4 == 0:
            if row_open:  # Si ya hay una fila abierta, cerrarla
                table_rows += "</tr>"
            table_rows += "<tr>"
            row_open = True

        # Agregar el producto como una celda
        table_rows += f"""
            <td>
                <div style="text-align: center;">
                    <img class="single-product" src="img/{product['photo']}.png" alt="{product['name']}" style="width: 100px; height: auto; display: block; margin: auto;" onclick="redireccion({product['id']})">
                    <p style="display: none;"><strong>ID:</strong> {product['id']}</p>
                    <p><strong>Nombre:</strong> {product['name']}</p>
                </div>
            </td>
        """

    # Cerrar la última fila si quedó abierta
    if row_open:
        table_rows += "</tr>"

    with app.app_context():
        rendered = render_template('index-clients.html', \
            title = "Todo a 100 Yuanes | Clientes", \
            products = table_rows)
    return rendered

@app.route('/vista-cliente-comprar', methods=['GET'])
def hello_world_product_client():
    req_product_id = request.args.get('id')

    with open("mysite/products.json", "r") as file:
        products = json.load(file)

    product_nombre = "AAAA"
    product_path = ""
    product_description = ""
    product_left = ""

    for product in products:
        if product["id"] == int(req_product_id):
            product_nombre = product["name"]
            product_path = product["photo"]
            product_description = product["description"]
            product_left = product["in_warehouse"]

    with app.app_context():
        rendered = render_template('product.html', \
            title = "Todo a 100 Yuanes | Clientes", \
            product_id = req_product_id, \
            product_name = product_nombre, \
            product_photo = product_path, \
            product_desc = product_description, \
            product_stock = product_left)
    return rendered

@app.route('/comprar-cliente', methods=['GET'])
def hello_world_product_buy():
    product_id = request.args.get('productid');
    product_quantity = request.args.get('cantidad');

    with open("mysite/products.json", "r") as file:
        products = json.load(file)

    for product in products:
        if product["id"] == int(product_id):
            new_qty = int(int(product["in_warehouse"]) - int(product_quantity))
            if new_qty < 0:
                new_qty = 0

            product["in_warehouse"] = int(new_qty)

    with open("mysite/products.json", "w") as file:
        json.dump(products, file, indent=4)

    with app.app_context():
        rendered = render_template('product-thanks.html', \
            title = "Todo a 100 Yuanes | Clientes")
    return rendered

@app.route('/vista-empresa-modificar', methods=['GET'])
def hello_world_product_modificar():
    req_product_id = request.args.get('id')

    with open("mysite/products.json", "r") as file:
        products = json.load(file)

    product_nombre = "AAAA"
    product_path = ""
    product_description = ""
    product_left = ""

    for product in products:
        if product["id"] == int(req_product_id):
            product_nombre = product["name"]
            product_path = product["photo"]
            product_description = product["description"]
            product_left = product["in_warehouse"]

    with app.app_context():
        rendered = render_template('product-modificar.html', \
            title = "Todo a 100 Yuanes | Clientes", \
            product_id = req_product_id, \
            product_name = product_nombre, \
            product_photo = product_path, \
            product_desc = product_description, \
            product_stock = product_left)
    return rendered

@app.route('/empresa-modificar', methods=['GET'])
def hello_world_product_mod():
    product_id = request.args.get('productid');
    product_quantity = request.args.get('cantidad');

    if not product_quantity.isdigit():
        return redirect(url_for('hello_world'))

    with open("mysite/products.json", "r") as file:
        products = json.load(file)

    for product in products:
        if product["id"] == int(product_id):
            product["in_warehouse"] = int(product_quantity)

    with open("mysite/products.json", "w") as file:
        json.dump(products, file, indent=4)

    return redirect(url_for('hello_world'))

@app.route('/last', methods=['GET', 'POST'] )
def getLastMessage():
    print("[WIMBITEK_log]: app-route(/last)")
    req_data =  request.args.get('id')
    print("[WIMBITEK_log]: parameter: (id="+str(req_data)+")")
    return str(req_data)

@app.route('/sigfox_payload', methods=['GET'] )
def getSigFoxMessage():
    print("[WIMBITEK_log]: app-route(/sigfox_message)")
    req_data_id =  request.args.get('id')
    req_data_time =  request.args.get('time')
    req_data_data =  request.args.get('data')

    print("[WIMBITEK_log]: body {id:"+str(req_data_id)+", data: "+str(req_data_data)+", time: "+str(req_data_time)+" }")
    return str("ACK")

@app.route('/sigfox_payload_withresponse', methods=['GET'] )
def getSigFoxMessageWithBackend():
    req_msg_id =  request.args.get('id')
    req_msg_time =  request.args.get('time')
    req_msg_data =  request.args.get('data')
    print("[WIMBITEK_log]: body {id:"+str(req_msg_id)+", data: "+str(req_msg_time)+", time: "+str(req_msg_data)+" }")

    return_value = "000000000000ffff"

    http_response = "HTTP/1.1 200 OK"+"\n"
    http_header = "Content-Type:application/json"+"\n\n"
    http_content = '{"' + req_msg_id + '":{"downlinkData":"' + return_value + '"}}'
    message_response = http_response + "" + http_header + "" + http_content
    print("[WIMBITEK_log]: "+str(message_response))

    return message_response

@app.route('/sigfox_payload_json', methods=['POST'] )
def getSigFoxPostMessage():
    global last_id
    global last_payload_a
    global last_payload_b
    global last_payload_total

    print("[WIMBITEK_log]: app-route /sigfox_message USING POST")
    print(str(request.data))
    print(str(request.json))

    req_msg_dev = request.json['device']
    req_msg_data = str(request.json['data'])

    ascii_text = bytes.fromhex(req_msg_data).decode('ascii')
    print(ascii_text)

    product_id = ascii_text[:2]
    presences = ascii_text[2:4]
    duration = ascii_text[4:6]
    units = ascii_text[6:8]

    hora_actual = datetime.now()

    hours = hora_actual.strftime("%H")
    minutes = hora_actual.strftime("%M")

    print("=== CURRENT TIME ===")
    print(hours)
    print(minutes)

    product_id = int(product_id)
    presences = int(presences)
    duration = int(duration)
    units = int(units)

    enough_products = 0

    with open("mysite/products.json", "r") as file:
        products = json.load(file)

    for product in products:
        if product["id"] == product_id:
            new_qty = int(product["in_warehouse"] - units)

            if new_qty < 0:
                new_qty = 0
                enough_products = 0
            else:
                enough_products = 1

            product["in_warehouse"] = new_qty

            product["avg_consume_rate"] = presences

            product["last_interaction_time"] = duration

            fecha_actual = datetime.now()

            dia = str(fecha_actual.day)
            mes = str(fecha_actual.month)
            new_consumed_date = "2025-0"+mes

            if int(dia) < 10:
                new_consumed_date += "-0"+dia
            else:
                new_consumed_date += "-"+dia

            new_consumed_date += "-"+str(hours)+"-"+str(minutes)

            fecha1 = datetime.strptime(product["last_restock"], "%Y-%m-%d-%H-%M")
            fecha2 = datetime.strptime(new_consumed_date, "%Y-%m-%d-%H-%M")

            new_time_between_restocks = fecha2 - fecha1
            diferencia_en_minutos = new_time_between_restocks.total_seconds() / 60

            product["avg_time_between_restocks"] = int(diferencia_en_minutos)

            product["last_restock"] = new_consumed_date

    with open("mysite/products.json", "w") as file:
        json.dump(products, file, indent=4)

    print("Product")
    print(product_id)

    print("Hours")
    print(hours)

    print("Minutes")
    print(minutes)

    print("Presences")
    print(presences)

    print("Duration")
    print(duration)

    print("Units")
    print(units)

    print("1-"+str(req_msg_dev))

    last_id = req_msg_dev
    last_payload_a = req_msg_data[1]

    last_payload_total = req_msg_data

    return_value = "0000000000000000"

    if enough_products == 0:
        return_value = "000000000000ffff"

    http_content = { req_msg_dev :{ "downlinkData": return_value }}
    js = json.dumps(http_content)
    print("2-"+str(js))

    resp = Response(js, status=200, mimetype='application/json')
    print("[WIMBITEK_log]: "+str(resp))

    return resp

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000, debug=True)


